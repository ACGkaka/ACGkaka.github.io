---
name: Bug修复
about: Something isn't working as expected
title: ''
labels: ''
assignees: ''

---

## ❓问题

<!-- 问题描述 -->

## 🤔结果 & 预期

Please describe what you expected to see.(请描述一下你希望看到什么)

## 🐥环境 & 设置

**Node.js & npm version**

```bash
```

**Your site `_config.yml`** (Optional)

```yml
```

**Your theme `_config.yml`** (Optional)

```yml
```

**Your browsers** (Optional)

> The browser you use

**Your OSes** (Optional)

> what platforms (operating systems and devices) are affected?

## 🙋Others

<!-- If you have other information. Please write here. -->